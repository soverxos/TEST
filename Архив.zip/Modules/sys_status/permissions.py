# Константы для разрешений модуля

# Имя модуля, должно совпадать с именем папки и 'name' в манифесте
MODULE_NAME = "sys_status"

# Разрешение на просмотр информации
PERM_VIEW_SYS_STATUS = f"{MODULE_NAME}.view"