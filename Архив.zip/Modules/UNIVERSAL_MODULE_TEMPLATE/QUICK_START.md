# 🚀 Быстрый старт с универсальным шаблоном модуля

Этот файл содержит пошаговые инструкции для быстрого создания нового модуля на основе универсального шаблона.

## 📋 Шаги создания нового модуля

### 1. Копирование шаблона

```bash
# Перейдите в директорию модулей
cd /path/to/SwiftDevBot-Project/modules

# Скопируйте шаблон
cp -r UNIVERSAL_MODULE_TEMPLATE my_new_module

# Перейдите в новую директорию
cd my_new_module
```

### 2. Переименование и обновление файлов

#### Обновите `manifest.yaml`:
```yaml
name: "my_new_module"  # Измените имя модуля
display_name: "Мой Новый Модуль"
description: "Описание вашего модуля"
author: "Ваше Имя"
```

#### Обновите `permissions.py`:
```python
MODULE_NAME = "my_new_module"  # Измените имя модуля
```

#### Обновите все остальные файлы:
Замените все вхождения `universal_template` на `my_new_module` в файлах:
- `__init__.py`
- `handlers.py`
- `services.py`
- `utils.py`
- `models.py`
- `callback_data_factories.py`
- `keyboards.py`

### 3. Настройка модуля

#### Обновите `module_settings.yaml`:
```yaml
enabled: true
max_items_per_user: 20  # Настройте под свои нужды
api_key: ""  # Добавьте API ключ, если нужен
debug_mode: false
```

### 4. Активация модуля

```bash
# Вернитесь в корень проекта
cd /path/to/SwiftDevBot-Project

# Активируйте модуль
python3 sdb.py module enable my_new_module

# Проверьте статус
python3 sdb.py module list
```

### 5. Тестирование

```bash
# Запустите тесты
python3 -m pytest modules/my_new_module/tests/

# Запустите бота
python3 sdb.py run
```

## 🎯 Основные команды для работы с модулем

### В Telegram:
- `/my_new_module` - главное меню модуля
- `/my_new_module_admin` - административная панель
- `/my_new_module_fsm` - демонстрация FSM диалога

### В CLI:
```bash
# Управление модулем
python3 sdb.py module enable my_new_module
python3 sdb.py module disable my_new_module
python3 sdb.py module reload my_new_module

# Настройки модуля
python3 sdb.py config set-module my_new_module enabled true
python3 sdb.py config set-module my_new_module max_items_per_user 50

# Просмотр логов
python3 sdb.py monitor logs --module my_new_module
```

## 🔧 Кастомизация под ваши нужды

### Добавление новых команд

1. В `manifest.yaml`:
```yaml
commands:
  - command: "my_command"
    description: "Описание команды"
    icon: "🔧"
    category: "Утилиты"
```

2. В `handlers.py`:
```python
@template_router.message(Command("my_command"))
async def my_command_handler(message: types.Message, services):
    await message.answer("Привет из моей команды!")
```

### Добавление новых разрешений

1. В `permissions.py`:
```python
class PERMISSIONS:
    MY_NEW_PERMISSION = f"{MODULE_NAME}.my_new_permission"
```

2. В `manifest.yaml`:
```yaml
permissions:
  - name: "my_new_module.my_new_permission"
    description: "Описание разрешения"
```

### Добавление новых моделей данных

1. В `models.py`:
```python
class MyNewModel(SDBBaseModel):
    __tablename__ = "my_new_table"
    
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    # Добавьте другие поля
```

2. В `manifest.yaml`:
```yaml
model_definitions:
  - "Modules.my_new_module.models.MyNewModel"
```

### Добавление новых настроек

1. В `manifest.yaml`:
```yaml
settings:
  my_new_setting:
    type: "string"
    label: "Моя новая настройка"
    description: "Описание настройки"
    default: "значение по умолчанию"
```

2. Используйте в коде:
```python
settings = services.modules.get_module_settings("my_new_module")
my_setting = settings.get('my_new_setting', 'default_value')
```

## 📚 Полезные ресурсы

### Документация:
- `README.md` - полная документация модуля
- `examples/` - примеры использования
- `tests/` - тесты для изучения

### Примеры файлов:
- `examples/basic_usage.py` - базовые примеры
- `examples/advanced_features.py` - продвинутые функции
- `examples/integration_examples.py` - интеграция с системой

### Тесты:
- `tests/test_handlers.py` - тесты обработчиков
- `tests/test_services.py` - тесты сервисов
- `tests/test_permissions.py` - тесты разрешений

## 🚨 Важные замечания

### Безопасность:
- Всегда проверяйте разрешения перед выполнением действий
- Валидируйте входные данные от пользователей
- Используйте параметризованные запросы для БД
- Логируйте важные действия в аудит

### Производительность:
- Используйте кэширование для часто запрашиваемых данных
- Ограничивайте размеры списков пагинацией
- Оптимизируйте запросы к БД
- Используйте асинхронные операции

### Качество кода:
- Следуйте PEP 8
- Используйте type hints
- Покрывайте код тестами
- Документируйте публичные API

## 🆘 Получение помощи

Если у вас возникли вопросы:

1. Изучите примеры в папке `examples/`
2. Посмотрите тесты в папке `tests/`
3. Обратитесь к документации SDB
4. Создайте issue в репозитории проекта

---

**Удачной разработки! 🎉**
