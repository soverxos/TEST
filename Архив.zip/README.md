# 🚀 SwiftDevBot (SDB) - Модульный Telegram Bot Framework

[![Python Version](https://img.shields.io/badge/python-3.12+-blue.svg)](https://python.org)
[![Aiogram](https://img.shields.io/badge/aiogram-3.22.0-green.svg)](https://aiogram.dev)
[![License](https://img.shields.io/badge/license-MIT-yellow.svg)](LICENSE)
[![GitHub Stars](https://img.shields.io/github/stars/soverxos/SwiftDevBot-Project.svg)](https://github.com/soverxos/SwiftDevBot-Project/stargazers)

**SwiftDevBot** - это мощный модульный фреймворк для создания Telegram ботов с продвинутой системой безопасности, RBAC, модульной архитектурой и богатым набором инструментов разработки.

## 📋 Содержание

- [🌟 Особенности](#-особенности)
- [⚡ Быстрый старт](#-быстрый-старт)
- [🏗️ Архитектура](#️-архитектура)
- [🔧 Установка](#-установка)
- [⚙️ Конфигурация](#️-конфигурация)
- [🧩 Модули](#-модули)
- [🛡️ Безопасность](#️-безопасность)
- [👥 RBAC система](#-rbac-система)
- [📊 CLI команды](#-cli-команды)
- [🗄️ База данных](#️-база-данных)
- [📈 Мониторинг](#-мониторинг)
- [🔨 Разработка](#-разработка)
- [📚 API документация](#-api-документация)
- [🤝 Вклад в проект](#-вклад-в-проект)
- [📄 Лицензия](#-лицензия)

## 🌟 Особенности

### 🎯 Основные возможности
- **Модульная архитектура** - легко расширяемая система плагинов
- **RBAC система** - ролевая модель доступа с детальными разрешениями
- **Продвинутая безопасность** - цифровые подписи, песочница, аудит
- **Многоязычность** - поддержка i18n из коробки
- **Асинхронность** - полная поддержка async/await
- **CLI управление** - богатый набор команд для администрирования
- **Мониторинг** - встроенная система аналитики и логирования
- **Кэширование** - поддержка Redis и Memory кэша
- **Миграции БД** - автоматические миграции через Alembic

### 🔒 Безопасность
- **Цифровые подписи модулей** - проверка целостности кода
- **Песочница выполнения** - изоляция модулей
- **Система репутации** - оценка надежности модулей
- **Аудит действий** - полное логирование операций
- **Сканирование кода** - автоматическое обнаружение угроз
- **Детекция аномалий** - выявление подозрительной активности

### 🧩 Модульность
- **Горячая перезагрузка** - обновление модулей без перезапуска
- **Зависимости модулей** - автоматическое разрешение зависимостей
- **Версионирование** - поддержка семантического версионирования
- **Шаблоны модулей** - готовые заготовки для быстрой разработки

## ⚡ Быстрый старт

### 🤖 Автоматическая настройка (рекомендуется)

**SwiftDevBot** включает в себя удобный мастер настройки, который автоматически выполнит всю первоначальную конфигурацию:

```bash
# 1. Клонирование репозитория
git clone https://github.com/soverxos/SwiftDevBot-Project.git
cd SwiftDevBot-Project

# 2. Запуск мастера настройки
python3 sdb_setup.py
```

Мастер настройки автоматически:
- ✅ Создаст виртуальное окружение
- ✅ Установит все зависимости
- ✅ Настроит базу данных (SQLite/PostgreSQL/MySQL)
- ✅ Настроит кэширование (Memory/Redis)
- ✅ Создаст структуру проекта
- ✅ Инициализирует базу данных
- ✅ Создаст конфигурационный файл `.env`

**Вам потребуется только:**
- Токен бота от [@BotFather](https://t.me/BotFather)
- Ваш Telegram ID (получить у [@userinfobot](https://t.me/userinfobot))

### 🔧 Ручная настройка

Если вы предпочитаете ручную настройку или хотите понять процесс детально:

#### 1. Клонирование репозитория
```bash
git clone https://github.com/soverxos/SwiftDevBot-Project.git
cd SwiftDevBot-Project
```

#### 2. Создание виртуального окружения
```bash
python3 -m venv .venv
source .venv/bin/activate  # Linux/Mac
# или
.venv\Scripts\activate     # Windows
```

#### 3. Установка зависимостей
```bash
pip install -r requirements.txt
```

#### 4. Настройка конфигурации
```bash
cp env.example .env
# Отредактируйте .env файл, добавив ваш BOT_TOKEN
```

#### 5. Инициализация базы данных
```bash
python3 sdb.py db init
python3 sdb.py db migrate
```

### 6. Запуск бота
```bash
python3 sdb.py run
```

### 7. Проверка статуса
```bash
python3 sdb.py status
```

## 🏗️ Архитектура

```
SwiftDevBot/
├── core/                    # Ядро системы
│   ├── app_settings.py      # Управление настройками
│   ├── bot_entrypoint.py    # Точка входа бота
│   ├── services_provider.py # Провайдер сервисов
│   ├── module_loader.py     # Загрузчик модулей
│   ├── database/            # Работа с БД
│   ├── security/            # Система безопасности
│   ├── rbac/                # Ролевая модель
│   ├── users/               # Управление пользователями
│   ├── cache/               # Система кэширования
│   ├── events/              # Система событий
│   └── ui/                  # UI компоненты
├── cli/                     # CLI команды
│   ├── run.py              # Управление запуском
│   ├── config.py           # Конфигурация
│   ├── module.py           # Управление модулями
│   ├── user.py             # Управление пользователями
│   ├── security.py         # Безопасность
│   └── ...
├── Modules/                 # Пользовательские модули
│   ├── sys_status/         # Системный модуль статуса
│   ├── example_module/     # Пример модуля
│   └── ...
├── project_data/            # Данные проекта
│   ├── Database_files/      # База данных
│   ├── Config/              # Конфигурации
│   ├── Security/            # Ключи и аудит
│   └── Logs/                # Логи
├── Docs/                    # Документация
├── locales/                 # Переводы
└── alembic/                 # Миграции БД
```

## 🔧 Установка

### Системные требования
- Python 3.12+
- SQLite/PostgreSQL/MySQL
- Redis (опционально)

### 🚀 Автоматическая установка (рекомендуется)

Используйте встроенный мастер настройки для автоматической установки:

```bash
# Клонирование и запуск мастера
git clone https://github.com/soverxos/SwiftDevBot-Project.git
cd SwiftDevBot-Project
python3 sdb_setup.py
```

Мастер автоматически:
- Создаст виртуальное окружение
- Установит все зависимости из `requirements.txt`
- Настроит конфигурацию
- Инициализирует базу данных

### 📦 Ручная установка зависимостей

#### Основные пакеты
```bash
pip install aiogram python-dotenv typer pydantic pydantic-settings
pip install PyYAML ruamel.yaml loguru aiohttp requests
pip install SQLAlchemy[asyncio] alembic aiosqlite psycopg[binary] aiomysql
pip install cachetools rich psutil uvicorn
```

#### Дополнительные пакеты для разработки
```bash
pip install pytest pylint sphinx coverage black isort mypy
pip install cryptography aioredis redis packaging parsedatetime apscheduler
```

### Настройка окружения

1. **Создайте файл `.env`**:
```env
# Telegram Bot
BOT_TOKEN=your_bot_token_here
SDB_CORE_SUPER_ADMINS="your_telegram_id"

# База данных
SDB_DB_TYPE="sqlite"
SDB_DB_SQLITE_PATH="Database_files/swiftdevbot.db"

# Кэш
SDB_CACHE_TYPE="memory"

# Логирование
SDB_CORE_LOG_LEVEL="INFO"
```

2. **Инициализируйте базу данных**:
```bash
python3 sdb.py db init
python3 sdb.py db migrate
```

## ⚙️ Конфигурация

### 🤖 Автоматическая конфигурация

**Рекомендуется использовать мастер настройки** `sdb_setup.py` для первоначальной конфигурации:

```bash
python3 sdb_setup.py
```

Мастер интерактивно настроит:
- Токен бота и администраторов
- Тип базы данных (SQLite/PostgreSQL/MySQL)
- Настройки кэширования (Memory/Redis)
- Структуру проекта
- Конфигурационный файл `.env`

### 🔧 Ручная конфигурация

### Основные настройки

#### Telegram Bot
```env
BOT_TOKEN=your_bot_token_here
SDB_TELEGRAM_POLLING_TIMEOUT=30
```

#### База данных
```env
# SQLite (по умолчанию)
SDB_DB_TYPE="sqlite"
SDB_DB_SQLITE_PATH="Database_files/swiftdevbot.db"

# PostgreSQL
SDB_DB_TYPE="postgresql"
SDB_DB_POSTGRES_HOST="localhost"
SDB_DB_POSTGRES_PORT="5432"
SDB_DB_POSTGRES_DB="swiftdevbot"
SDB_DB_POSTGRES_USER="user"
SDB_DB_POSTGRES_PASSWORD="password"

# MySQL
SDB_DB_TYPE="mysql"
SDB_DB_MYSQL_HOST="localhost"
SDB_DB_MYSQL_PORT="3306"
SDB_DB_MYSQL_DB="swiftdevbot"
SDB_DB_MYSQL_USER="user"
SDB_DB_MYSQL_PASSWORD="password"
```

#### Кэширование
```env
# Memory кэш (по умолчанию)
SDB_CACHE_TYPE="memory"

# Redis кэш
SDB_CACHE_TYPE="redis"
SDB_CACHE_REDIS_HOST="localhost"
SDB_CACHE_REDIS_PORT="6379"
SDB_CACHE_REDIS_DB="0"
SDB_CACHE_REDIS_PASSWORD=""
```

#### Безопасность
```env
SDB_SECURITY_LEVEL="moderate"  # strict, moderate, permissive
SDB_SECURITY_SIGNATURE_REQUIRED="true"
SDB_SECURITY_SANDBOX_ENABLED="true"
```

### Расширенная конфигурация

Создайте файл `project_data/Config/core_settings.yaml` для детальной настройки:

```yaml
core:
  sdb_version: "0.1.0"
  project_data_path: "./project_data"
  log_level: "INFO"
  super_admins: [123456789]
  
telegram:
  token: "your_bot_token"
  polling_timeout: 30
  
database:
  type: "sqlite"
  sqlite_path: "Database_files/swiftdevbot.db"
  
cache:
  type: "memory"
  default_ttl: 300
  
security:
  level: "moderate"
  signature_required: true
  sandbox_enabled: true
```

## 🧩 Модули

### Создание модуля

1. **Создайте директорию модуля**:
```bash
mkdir Modules/my_module
cd Modules/my_module
```

2. **Создайте манифест модуля** (`manifest.yaml`):
```yaml
name: "my_module"
version: "1.0.0"
display_name: "Мой Модуль"
description: "Описание модуля"
author: "Ваше Имя"
license: "MIT"

permissions:
  - name: "my_module.access"
    description: "Доступ к модулю"
    default_roles: ["User"]

settings:
  - name: "enabled"
    type: "boolean"
    default: true
    description: "Включить модуль"
```

3. **Создайте основной файл модуля** (`__init__.py`):
```python
from aiogram import Router, types
from aiogram.filters import Command
from core.schemas.module_manifest import ModuleManifest

router = Router()

@router.message(Command("mymodule"))
async def my_module_handler(message: types.Message):
    await message.answer("Привет из моего модуля!")

async def setup_module(dp, bot, manifest: ModuleManifest):
    """Настройка модуля"""
    dp.include_router(router)
    print(f"Модуль {manifest.name} загружен!")
```

### Активация модуля

```bash
# Показать все модули
python3 sdb.py module list

# Активировать модуль
python3 sdb.py module enable my_module

# Деактивировать модуль
python3 sdb.py module disable my_module

# Перезагрузить модуль
python3 sdb.py module reload my_module
```

### Встроенные модули

- **sys_status** - отображение системной информации
- **example_module** - пример модуля с полным функционалом
- **universal_module_template** - шаблон для создания модулей

## 🛡️ Безопасность

### Цифровые подписи

Все модули должны быть подписаны цифровой подписью:

```bash
# Генерация ключа
python3 sdb.py security generate-key

# Подписание модуля
python3 sdb.py security sign-module my_module

# Проверка подписи
python3 sdb.py security verify-module my_module
```

### Песочница

Модули выполняются в изолированной среде с ограниченными правами:

- **Уровень 1**: Полный доступ (только системные модули)
- **Уровень 2**: Ограниченный доступ к файловой системе
- **Уровень 3**: Только чтение конфигурации
- **Уровень 4**: Максимальные ограничения

### Аудит

Все действия пользователей и модулей логируются:

```bash
# Просмотр логов аудита
python3 sdb.py security audit-logs

# Просмотр логов конкретного пользователя
python3 sdb.py security audit-logs --user 123456789
```

## 👥 RBAC система

### Роли по умолчанию

- **Admin** - полный доступ ко всем функциям
- **Moderator** - управление пользователями и модулями
- **User** - базовые функции

### Управление ролями

```bash
# Создание роли
python3 sdb.py user create-role "CustomRole"

# Назначение разрешений
python3 sdb.py user assign-permission CustomRole my_module.access

# Назначение роли пользователю
python3 sdb.py user assign-role 123456789 CustomRole
```

### Разрешения

Система поддерживает детальные разрешения:

- `core.admin.*` - административные функции
- `core.modules.*` - управление модулями
- `core.users.*` - управление пользователями
- `module_name.action` - действия модуля

## 📊 CLI команды

### Управление ботом
```bash
python3 sdb.py run              # Запуск бота
python3 sdb.py start            # Псевдоним для run
python3 sdb.py stop             # Остановка бота
python3 sdb.py restart          # Перезапуск бота
python3 sdb.py status           # Статус бота
```

### Конфигурация
```bash
python3 sdb.py config init      # Интерактивная настройка
python3 sdb.py config get        # Показать конфигурацию
python3 sdb.py config set key value  # Установить значение
```

### База данных
```bash
python3 sdb.py db init          # Инициализация БД
python3 sdb.py db migrate        # Применить миграции
python3 sdb.py db upgrade        # Обновить схему
python3 sdb.py db downgrade      # Откатить изменения
```

### Модули
```bash
python3 sdb.py module list       # Список модулей
python3 sdb.py module enable name    # Активировать модуль
python3 sdb.py module disable name   # Деактивировать модуль
python3 sdb.py module reload name     # Перезагрузить модуль
python3 sdb.py module install path   # Установить модуль
```

### Пользователи
```bash
python3 sdb.py user list         # Список пользователей
python3 sdb.py user create       # Создать пользователя
python3 sdb.py user delete id    # Удалить пользователя
python3 sdb.py user assign-role user_id role  # Назначить роль
```

### Безопасность
```bash
python3 sdb.py security status   # Статус безопасности
python3 sdb.py security scan     # Сканирование модулей
python3 sdb.py security audit-logs  # Логи аудита
python3 sdb.py security generate-key  # Генерация ключа
```

### Мониторинг
```bash
python3 sdb.py monitor stats     # Статистика системы
python3 sdb.py monitor logs      # Просмотр логов
python3 sdb.py monitor performance  # Производительность
```

### Бэкапы
```bash
python3 sdb.py backup create     # Создать бэкап
python3 sdb.py backup list       # Список бэкапов
python3 sdb.py backup restore id # Восстановить бэкап
```

## 🗄️ База данных

### Поддерживаемые СУБД

- **SQLite** (по умолчанию) - для разработки и небольших проектов
- **PostgreSQL** - для продакшена
- **MySQL** - альтернатива PostgreSQL

### Миграции

Система использует Alembic для управления миграциями:

```bash
# Создание миграции
python3 sdb.py db create-migration "description"

# Применение миграций
python3 sdb.py db migrate

# Откат миграции
python3 sdb.py db downgrade
```

### Схема базы данных

Основные таблицы:
- `sdb_users` - пользователи
- `sdb_roles` - роли
- `sdb_permissions` - разрешения
- `sdb_user_roles` - связи пользователей и ролей
- `sdb_role_permissions` - связи ролей и разрешений
- `alembic_version` - версии миграций

## 📈 Мониторинг

### Системная информация

```bash
# Общая статистика
python3 sdb.py monitor stats

# Производительность
python3 sdb.py monitor performance

# Использование ресурсов
python3 sdb.py monitor resources
```

### Логирование

Система использует Loguru для продвинутого логирования:

- **Консольные логи** - для разработки
- **Файловые логи** - для продакшена
- **Структурированные логи** - для анализа
- **Ротация логов** - автоматическая очистка

### Метрики

Встроенные метрики:
- Количество активных пользователей
- Использование модулей
- Производительность системы
- Ошибки и исключения

## 🔨 Разработка

### 🚀 Быстрый старт для разработчиков

1. **Клонирование и настройка**:
```bash
git clone https://github.com/soverxos/SwiftDevBot-Project.git
cd SwiftDevBot-Project
python3 sdb_setup.py  # Автоматическая настройка
```

2. **Запуск в режиме разработки**:
```bash
python3 sdb.py run --debug
```

### Структура проекта

```
core/
├── app_settings.py      # Настройки приложения
├── bot_entrypoint.py    # Точка входа бота
├── services_provider.py # Провайдер сервисов
├── module_loader.py     # Загрузчик модулей
├── database/            # Работа с БД
│   ├── manager.py       # Менеджер БД
│   └── models.py        # Модели данных
├── security/            # Безопасность
│   ├── signature_manager.py  # Управление подписями
│   ├── sandbox_manager.py    # Песочница
│   └── audit_logger.py       # Аудит
└── ...
```

### Создание CLI команды

1. **Создайте файл команды** в `cli/`:
```python
import typer
from core.app_settings import load_app_settings

app = typer.Typer(name="mycommand", help="Моя команда")

@app.command()
def my_action():
    """Описание действия"""
    settings = load_app_settings()
    print("Выполняется действие...")

if __name__ == "__main__":
    app()
```

2. **Зарегистрируйте команду** в `sdb.py`:
```python
from cli.mycommand import app as mycommand_app
cli_main_app.add_typer(mycommand_app, name="mycommand")
```

### Тестирование

```bash
# Запуск тестов
python3 -m pytest

# Тесты с покрытием
python3 -m pytest --cov=core

# Конкретный тест
python3 -m pytest tests/test_module_loader.py
```

### Линтинг

```bash
# Проверка кода
python3 -m pylint core/
python3 -m black core/
python3 -m isort core/
python3 -m mypy core/
```

## 📚 API документация

### Основные классы

#### BotServicesProvider
Центральный класс для управления сервисами:
```python
from core.services_provider import BotServicesProvider
from core.app_settings import load_app_settings

settings = load_app_settings()
services = BotServicesProvider(settings)
await services.setup_services()

# Доступ к сервисам
db_manager = services._db_manager
module_loader = services._module_loader
```

#### ModuleLoader
Управление модулями:
```python
# Получение информации о модуле
module_info = module_loader.get_module_info("module_name")

# Получение всех модулей
all_modules = module_loader.get_all_modules_info()

# Загруженные модули
loaded_modules = module_loader.get_loaded_modules_info()
```

#### AppSettings
Управление настройками:
```python
from core.app_settings import load_app_settings

settings = load_app_settings()
print(settings.telegram.token)
print(settings.db.type)
print(settings.core.super_admins)
```

### События

Система событий для интеграции модулей:

```python
from core.events.dispatcher import EventDispatcher

# Подписка на событие
@event_dispatcher.on("user_registered")
async def on_user_registered(user_id: int):
    print(f"Пользователь {user_id} зарегистрирован")

# Отправка события
await event_dispatcher.emit("user_registered", user_id=123456789)
```

### Кэширование

```python
from core.cache.manager import CacheManager

# Сохранение в кэш
await cache_manager.set("key", "value", ttl=300)

# Получение из кэша
value = await cache_manager.get("key")

# Удаление из кэша
await cache_manager.delete("key")
```

## 🤝 Вклад в проект

Мы приветствуем вклад в развитие проекта! Вот как вы можете помочь:

### 🚀 Быстрый старт для контрибьюторов

1. **Настройка окружения разработки**:
```bash
git clone https://github.com/soverxos/SwiftDevBot-Project.git
cd SwiftDevBot-Project
python3 sdb_setup.py  # Автоматическая настройка
```

2. **Запуск тестов**:
```bash
python3 sdb.py test
```

### Сообщение об ошибках
1. Проверьте существующие issues
2. Создайте новый issue с подробным описанием
3. Укажите версию Python, ОС и шаги воспроизведения

### Предложение улучшений
1. Создайте issue с тегом "enhancement"
2. Опишите предлагаемое улучшение
3. Обоснуйте необходимость изменения

### Pull Request
1. Форкните репозиторий
2. Создайте ветку для ваших изменений
3. Сделайте коммиты с понятными сообщениями
4. Создайте Pull Request

### Стандарты кода
- Следуйте PEP 8
- Используйте type hints
- Покрывайте код тестами
- Документируйте публичные API

### Коммиты
Используйте понятные сообщения коммитов:
```
feat: добавить новую команду CLI
fix: исправить ошибку в загрузке модулей
docs: обновить документацию API
test: добавить тесты для ModuleLoader
```

## 📄 Лицензия

Этот проект распространяется под лицензией MIT. См. файл [LICENSE](LICENSE) для подробностей.

## 🙏 Благодарности

- [aiogram](https://aiogram.dev) - асинхронный фреймворк для Telegram Bot API
- [SQLAlchemy](https://sqlalchemy.org) - ORM для работы с базами данных
- [Typer](https://typer.tiangolo.com) - фреймворк для создания CLI приложений
- [Pydantic](https://pydantic.dev) - валидация данных
- [Loguru](https://loguru.readthedocs.io) - продвинутое логирование

## 📞 Поддержка

- **GitHub Issues**: [Создать issue](https://github.com/soverxos/SwiftDevBot-Project/issues)
- **Discussions**: [Обсуждения](https://github.com/soverxos/SwiftDevBot-Project/discussions)
- **Telegram**: [@soverxos](https://t.me/soverxos)

## 🚀 Roadmap

### Версия 0.2.0
- [ ] Web интерфейс для администрирования
- [ ] Плагин система для CLI
- [ ] Расширенная аналитика
- [ ] Интеграция с внешними API

### Версия 0.3.0
- [ ] Микросервисная архитектура
- [ ] Kubernetes поддержка
- [ ] GraphQL API
- [ ] Машинное обучение для детекции аномалий

---

**SwiftDevBot** - создан с ❤️ для сообщества разработчиков Telegram ботов.

⭐ Поставьте звезду, если проект вам понравился!
