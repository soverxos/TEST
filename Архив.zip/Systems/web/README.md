# SwiftDevBot Web Dashboard

Футуристическая веб-панель управления Telegram-ботом SwiftDevBot на React + TypeScript + Vite в стиле Liquid Glass Interface.

## 🎨 Особенности

- **React + TypeScript** - Современный стек с типобезопасностью
- **Vite** - Быстрая сборка и разработка
- **Liquid Glass Design** - Прозрачные стеклянные элементы с эффектами размытия
- **Holographic UI** - Неоновые акценты и световые эффекты
- **Tailwind CSS** - Утилитарные стили
- **Двухтема** - Светлая и темная тема с плавными переходами
- **Адаптивный дизайн** - Оптимизирован для всех устройств
- **RBAC система** - Разделение доступа для пользователей и администраторов

## 🚀 Быстрый старт

### Установка зависимостей

```bash
cd Systems/web
npm install
```

### Разработка

```bash
# Запуск dev сервера (Vite)
npm run dev

# В отдельном терминале запустите FastAPI backend
python3 ../../sdb.py web start
```

Frontend будет доступен на `http://localhost:5173` (Vite dev server)
Backend API на `http://localhost:8000`

### Сборка для production

```bash
# Собрать фронтенд
npm run build

# Запустить FastAPI (автоматически обслуживает собранный фронтенд)
python3 ../../sdb.py web start
```

После сборки фронтенд будет доступен через FastAPI на `http://localhost:8000`

## 📁 Структура проекта

```
Systems/web/
├── src/
│   ├── components/          # React компоненты
│   │   ├── ui/              # UI компоненты (GlassCard, GlassButton, etc.)
│   │   ├── sections/        # Секции dashboard (Home, Modules, Users, etc.)
│   │   ├── Header.tsx       # Шапка
│   │   ├── Sidebar.tsx      # Боковое меню
│   │   └── AnimatedBackground.tsx
│   ├── contexts/             # React Contexts
│   │   ├── AuthContext.tsx  # Аутентификация
│   │   └── ThemeContext.tsx # Управление темой
│   ├── lib/
│   │   └── api.ts           # FastAPI клиент
│   ├── pages/
│   │   ├── Login.tsx        # Страница входа
│   │   └── Dashboard.tsx    # Главная панель
│   ├── App.tsx              # Главный компонент
│   ├── main.tsx             # Точка входа
│   └── index.css            # Глобальные стили
├── app.py                   # FastAPI backend
├── vite.config.ts           # Конфигурация Vite
├── tailwind.config.js       # Конфигурация Tailwind
├── tsconfig.json            # Конфигурация TypeScript
└── package.json             # Зависимости
```

## 🔐 Авторизация

### Роли

- **User** - Стандартный доступ к панели (модули, профиль, статистика)
- **Admin** - Полный доступ, включая административные разделы

### Демо-режим

В текущей версии для демонстрации любая пара логин/пароль принимается. В продакшене необходимо настроить реальную аутентификацию через API.

## 📱 Разделы панели

### Для всех пользователей

1. **Home** - Обзор состояния бота
2. **Modules** - Управление модулями бота
3. **Users** - Список пользователей
4. **Statistics** - Графики и метрики
5. **Logs** - Логи в реальном времени
6. **Settings** - Конфигурация панели
7. **Documentation** - Документация и помощь

### Только для администраторов

8. **Core Config** - Настройки ядра системы
9. **Services** - Управление системными сервисами
10. **Monitoring** - Системные метрики

## 🎨 Цветовые темы

### Светлая тема
- Белый фон с легким синим свечением
- Мягкие тени и отражения
- Элементы под стеклом

### Темная тема
- Градиент от темно-синего к лазурному
- Неоновые акценты (бирюзовый, лаймовый, фиолетовый)
- Анимированные световые блики

## 🔧 API Endpoints

### Аутентификация
- `POST /api/auth/login` - Вход
- `POST /api/auth/logout` - Выход

### Данные
- `GET /api/health` - Проверка состояния
- `GET /api/stats` - Статистика бота
- `GET /api/modules` - Список модулей
- `GET /api/users` - Список пользователей
- `GET /api/logs` - Логи (с фильтрацией по уровню)

## ⚙️ Конфигурация

### Переменные окружения

Создайте файл `.env` в `Systems/web/`:

```env
VITE_API_BASE_URL=http://localhost:8000
```

### Vite Proxy

В режиме разработки Vite проксирует запросы к `/api` на FastAPI backend (`http://localhost:8000`).

## 📝 Технические детали

- **Frontend**: React 18, TypeScript, Vite
- **Styling**: Tailwind CSS, Custom CSS (Liquid Glass)
- **Icons**: Lucide React
- **Backend**: FastAPI (Python)
- **Стили**: Liquid Glass, Glassmorphism, Neon Cyberpunk
- **Шрифты**: System fonts (Inter fallback)
- **Анимации**: CSS Animations, Transitions

## 🛠️ Команды

```bash
# Разработка
npm run dev          # Запустить dev server
npm run build        # Собрать для production
npm run preview      # Предпросмотр production build
npm run lint         # Проверить код линтером
npm run typecheck    # Проверить типы TypeScript

# Backend
python3 ../../sdb.py web start    # Запустить FastAPI сервер
```

## 🎯 Планы развития

- [ ] Интеграция с реальными данными бота через sdb_services
- [ ] WebSocket для real-time обновлений
- [ ] Расширенная система графиков (Chart.js/Recharts)
- [ ] Экспорт логов и статистики
- [ ] Настройки уведомлений
- [ ] Многоязычная поддержка
- [ ] JWT токены для безопасной аутентификации

## 📚 Документация

- [React Docs](https://react.dev)
- [TypeScript Docs](https://www.typescriptlang.org)
- [Vite Docs](https://vitejs.dev)
- [Tailwind CSS Docs](https://tailwindcss.com)

---

**SwiftDevBot** — создан с ❤️ командой SoverX
