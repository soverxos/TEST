# core/users/__init__.py
from .service import UserService

__all__ = ["UserService"]