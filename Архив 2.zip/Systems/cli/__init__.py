# cli_commands/__init__.py
# Делает cli_commands пакетом
