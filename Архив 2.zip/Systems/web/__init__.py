# Systems/web/__init__.py
"""
Web interface for SwiftDevBot dashboard (React + TypeScript + Vite).
"""
