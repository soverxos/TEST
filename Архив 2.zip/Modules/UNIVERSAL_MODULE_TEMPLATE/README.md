# 🔧 Универсальный шаблон модуля SDB

Этот модуль является полным шаблоном для создания любых модулей в системе SwiftDevBot (SDB). Он демонстрирует все возможности системы модулей и может служить основой для разработки собственных модулей.

## 📋 Содержание

- [Возможности шаблона](#возможности-шаблона)
- [Структура модуля](#структура-модуля)
- [Установка и настройка](#установка-и-настройка)
- [Использование](#использование)
- [Разработка](#разработка)
- [API документация](#api-документация)
- [Примеры](#примеры)

## 🌟 Возможности шаблона

### Основные функции
- ✅ **CRUD операции** - создание, чтение, обновление, удаление данных
- ✅ **FSM диалоги** - многошаговые диалоги с пользователем
- ✅ **Система разрешений** - интеграция с RBAC системой SDB
- ✅ **Работа с БД** - модели SQLAlchemy и автоматические миграции
- ✅ **Настройки модуля** - гибкая система конфигурации
- ✅ **Аудит и логирование** - полное логирование действий
- ✅ **UI компоненты** - клавиатуры, callback data, навигация
- ✅ **Обработка ошибок** - корректная обработка исключений

### Демонстрационные возможности
- 📝 Создание и управление элементами данных
- 📊 Статистика и аналитика
- ⚙️ Административная панель
- 🗣️ FSM диалоги для ввода данных
- 🔐 Проверка разрешений на всех уровнях
- 📱 Адаптивные интерфейсы

## 🏗️ Структура модуля

```
UNIVERSAL_MODULE_TEMPLATE/
├── __init__.py                    # Точка входа модуля
├── manifest.yaml                  # Манифест с полным набором опций
├── handlers.py                    # Обработчики команд и сообщений
├── keyboards.py                   # Клавиатуры и inline кнопки
├── callback_data_factories.py     # Фабрики callback data
├── permissions.py                 # Определения разрешений
├── models.py                      # Модели данных SQLAlchemy
├── services.py                    # Бизнес-логика и работа с БД
├── utils.py                       # Вспомогательные функции
├── module_settings.yaml           # Настройки по умолчанию
├── README.md                      # Документация модуля
├── examples/                      # Примеры использования
│   ├── basic_usage.py
│   ├── advanced_features.py
│   └── integration_examples.py
└── tests/                         # Тесты модуля
    ├── test_handlers.py
    ├── test_services.py
    └── test_permissions.py
```

## 🚀 Установка и настройка

### 1. Копирование шаблона

```bash
# Скопируйте папку шаблона
cp -r modules/UNIVERSAL_MODULE_TEMPLATE modules/my_new_module

# Переименуйте файлы и обновите содержимое
cd modules/my_new_module
```

### 2. Обновление манифеста

Отредактируйте `manifest.yaml`:

```yaml
name: "my_new_module"  # Измените имя модуля
display_name: "Мой Новый Модуль"
description: "Описание вашего модуля"
author: "Ваше Имя"
```

### 3. Обновление кода

Замените все вхождения `universal_template` на `my_new_module` в файлах:
- `__init__.py`
- `permissions.py`
- `handlers.py`
- `services.py`
- `utils.py`
- `models.py`

### 4. Активация модуля

```bash
# Активируйте модуль
python3 sdb.py module enable my_new_module

# Проверьте статус
python3 sdb.py module list
```

## 💻 Использование

### Команды бота

- `/template` - главное меню модуля
- `/template_admin` - административная панель
- `/template_fsm` - демонстрация FSM диалога

### Основные функции

1. **Создание элементов** - многошаговый диалог для создания данных
2. **Просмотр списка** - пагинированный список элементов
3. **Управление данными** - редактирование и удаление
4. **Статистика** - персональная и глобальная статистика
5. **Настройки** - конфигурация модуля

## 🔧 Разработка

### Добавление новых функций

1. **Новые команды** - добавьте в `manifest.yaml` и создайте обработчики в `handlers.py`
2. **Новые разрешения** - определите в `permissions.py` и добавьте в манифест
3. **Новые модели** - создайте в `models.py` и обновите манифест
4. **Новая бизнес-логика** - добавьте методы в `services.py`

### Пример добавления новой команды

1. В `manifest.yaml`:
```yaml
commands:
  - command: "my_new_command"
    description: "Описание новой команды"
    icon: "🔧"
    category: "Утилиты"
```

2. В `handlers.py`:
```python
@template_router.message(Command("my_new_command"))
async def my_new_command(message: types.Message, services: 'BotServicesProvider'):
    # Ваш код здесь
    pass
```

### Пример добавления нового разрешения

1. В `permissions.py`:
```python
class PERMISSIONS:
    MY_NEW_PERMISSION = f"{MODULE_NAME}.my_new_permission"
```

2. В `manifest.yaml`:
```yaml
permissions:
  - name: "my_new_module.my_new_permission"
    description: "Описание разрешения"
```

## 📚 API документация

### TemplateService

Основной сервис для работы с данными модуля.

#### Методы

- `create_item(user_id, title, description, priority, tags)` - создание элемента
- `get_user_items(user_id, include_inactive)` - получение элементов пользователя
- `get_item_by_id(item_id, user_id)` - получение элемента по ID
- `update_item(item_id, user_id, **kwargs)` - обновление элемента
- `delete_item(item_id, user_id)` - удаление элемента
- `get_user_stats(user_id)` - статистика пользователя
- `get_global_stats()` - глобальная статистика

### Утилиты

- `check_permission(services, user_id, permission)` - проверка разрешения
- `validate_input(data, min_length, max_length)` - валидация ввода
- `format_user_info(user_data)` - форматирование информации о пользователе
- `log_module_action(services, action, user_id, details)` - логирование действий

## 🎯 Примеры

### Базовое использование

```python
# Создание элемента
template_service = TemplateService(services, settings)
new_item = await template_service.create_item(
    user_id=123456789,
    title="Мой элемент",
    description="Описание элемента",
    priority=50
)

# Получение элементов пользователя
items = await template_service.get_user_items(123456789)
```

### Проверка разрешений

```python
# Проверка доступа
if await check_permission(services, user_id, PERMISSIONS.ACCESS):
    # Пользователь имеет доступ
    pass
```

### FSM диалог

```python
# Начало диалога
await state.set_state(TemplateStates.waiting_input)

# Обработка ввода
@template_router.message(StateFilter(TemplateStates.waiting_input))
async def process_input(message: types.Message, state: FSMContext):
    # Обработка введенных данных
    pass
```

## 🧪 Тестирование

### Запуск тестов

```bash
# Запуск всех тестов модуля
python3 -m pytest modules/UNIVERSAL_MODULE_TEMPLATE/tests/

# Запуск конкретного теста
python3 -m pytest modules/UNIVERSAL_MODULE_TEMPLATE/tests/test_handlers.py
```

### Создание тестов

```python
# Пример теста
import pytest
from Modules.universal_template.services import TemplateService

@pytest.mark.asyncio
async def test_create_item():
    # Тест создания элемента
    pass
```

## 🔒 Безопасность

### Рекомендации

1. **Всегда проверяйте разрешения** перед выполнением действий
2. **Валидируйте входные данные** от пользователей
3. **Используйте параметризованные запросы** для работы с БД
4. **Логируйте важные действия** в аудит
5. **Обрабатывайте исключения** корректно

### Пример безопасной проверки

```python
async def safe_action(message: types.Message, services: 'BotServicesProvider'):
    # Проверяем разрешение
    if not await check_permission(services, message.from_user.id, PERMISSIONS.ACTION):
        await message.answer("❌ Нет доступа")
        return
    
    # Валидируем данные
    if not validate_input(message.text):
        await message.answer("❌ Некорректные данные")
        return
    
    # Выполняем действие
    try:
        result = await perform_action(message.text)
        await message.answer(f"✅ Результат: {result}")
    except Exception as e:
        logger.error(f"Ошибка выполнения действия: {e}")
        await message.answer("❌ Произошла ошибка")
```

## 📞 Поддержка

Если у вас возникли вопросы по использованию шаблона:

1. Изучите примеры в папке `examples/`
2. Посмотрите тесты в папке `tests/`
3. Обратитесь к документации SDB
4. Создайте issue в репозитории проекта

## 📄 Лицензия

Этот шаблон распространяется под той же лицензией, что и основной проект SwiftDevBot.

---

**Удачной разработки! 🚀**
